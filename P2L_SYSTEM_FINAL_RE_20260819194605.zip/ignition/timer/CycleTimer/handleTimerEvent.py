def handleTimerEvent():
	cycleTimer.tick()	