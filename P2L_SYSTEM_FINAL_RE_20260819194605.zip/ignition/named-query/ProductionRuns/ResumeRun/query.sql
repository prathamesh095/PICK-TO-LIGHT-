UPDATE production_runs

SET

    machine_state = 'RUNNING',

    status = 'ACTIVE',

    is_paused = FALSE,

    total_pause_seconds = :TotalPauseSeconds

WHERE run_id = :RunID;