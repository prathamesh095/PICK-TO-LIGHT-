UPDATE production_runs

SET run_number =
'RUN-' || LPAD(CAST(:RunID AS TEXT),6,'0')

WHERE run_id = :RunID;