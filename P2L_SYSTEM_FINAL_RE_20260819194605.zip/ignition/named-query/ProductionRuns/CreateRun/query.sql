INSERT INTO production_runs (

    recipe_id,
    product_id,
    operator_name,
    machine_name,
    start_time,
    status,
    machine_state,
    completed,
    completed_steps,
    total_steps,
    total_cycle_seconds,
    total_pause_seconds,
    created_at

)

VALUES (

    :RecipeID,
    :ProductID,
    :OperatorName,
    :MachineName,

    CURRENT_TIMESTAMP,

    'ACTIVE',
    'RUNNING',

    FALSE,

    0,

    :TotalSteps,

    0,
    0,

    CURRENT_TIMESTAMP

)

RETURNING run_id;