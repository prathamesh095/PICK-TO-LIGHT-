UPDATE production_runs
SET

    total_cycle_seconds = :ElapsedSeconds,

    completed_steps = :CompletedSteps,

    machine_state = :MachineState,

    status = :Status

WHERE run_id = :RunID;