UPDATE production_runs
SET

    end_time = NOW(),

    total_cycle_seconds = :CycleSeconds,

    total_pause_seconds = :PauseSeconds,

    machine_state='ABORTED',

    status='ABORTED',

    completed=FALSE

WHERE run_id=:RunID;