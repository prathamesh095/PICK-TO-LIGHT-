UPDATE production_runs

SET

    end_time = CURRENT_TIMESTAMP,

    actual_cycle_seconds = :ActualCycleSeconds,

    total_cycle_seconds = :ActualCycleSeconds,

    completed_steps = :CompletedSteps,

    machine_state = 'COMPLETED',

    status = 'COMPLETED',

    completed = TRUE,

    completion_reason = 'SUCCESS'

WHERE run_id = :RunID;