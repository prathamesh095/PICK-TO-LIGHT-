UPDATE production_runs

SET

    machine_state = 'PAUSED',

    status = 'PAUSED',

    is_paused = TRUE

WHERE run_id = :RunID;