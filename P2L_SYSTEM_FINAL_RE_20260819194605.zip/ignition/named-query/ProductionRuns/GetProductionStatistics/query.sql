SELECT

    COUNT(*) AS total_runs,

    COUNT(*) FILTER (
        WHERE completed = TRUE
    ) AS good_runs,

    COUNT(*) FILTER (
        WHERE completed = FALSE
    ) AS failed_runs,

    COALESCE(
        AVG(actual_cycle_seconds),
        0
    )::INTEGER AS average_cycle,

    COALESCE(
        MIN(actual_cycle_seconds),
        0
    ) AS best_cycle

FROM production_runs;