SELECT
	step_no,
	bin_id,
	quantity,
	instruction
FROM recipe_steps
WHERE recipe_id=:recipeID and step_no= :stepNo
ORDER BY step_no;