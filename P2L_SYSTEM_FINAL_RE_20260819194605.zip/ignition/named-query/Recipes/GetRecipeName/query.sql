SELECT
    recipe_name
FROM recipes
WHERE product_id = :productID
AND active = TRUE;