SELECT
    recipe_id,
    recipe_name,
    version
FROM recipes
WHERE product_id = :productID
AND active = TRUE;