SELECT

    rs.step_no,
    rs.bin_id,
    rs.quantity,

    p.part_number,
    p.part_name,

    rs.instruction

FROM recipe_steps rs

JOIN bins b
ON rs.bin_id = b.bin_id

JOIN parts p
ON b.part_id = p.part_id

WHERE rs.recipe_id = :recipeID

ORDER BY rs.step_no;