SELECT COUNT(*) AS total_steps
FROM recipe_steps
WHERE recipe_id = :recipeID;