SELECT 
	product_name
FROM products
WHERE active = TRUE and product_id = :productID
ORDER BY product_name;