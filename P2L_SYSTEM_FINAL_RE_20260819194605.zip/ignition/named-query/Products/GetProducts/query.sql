SELECT 
	product_id,
	product_code,
	product_name
FROM products
WHERE active = TRUE
ORDER BY product_name;