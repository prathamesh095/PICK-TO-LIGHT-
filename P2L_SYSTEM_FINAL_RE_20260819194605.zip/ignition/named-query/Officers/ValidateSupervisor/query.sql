SELECT

    username

FROM supervisors

WHERE

    username = :username
    AND password = :password
    AND active = TRUE

LIMIT 1;