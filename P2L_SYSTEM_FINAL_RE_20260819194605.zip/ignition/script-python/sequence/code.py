LOGGER = system.util.getLogger("P2L.Sequence")

RUNTIME = "[P2L_TagProvider]Runtime/"
DEVICES = "[P2L_TagProvider]Devices"


def clearOutputs():
    """
    Turns OFF every output on every sensor.
    """

    try:

        sensors = system.tag.browse(DEVICES).getResults()

        tagPaths = []
        values = []

        for sensor in sensors:

            sensorPath = str(sensor["fullPath"])

            tagPaths.extend([
                sensorPath + "/Out/Green",
                sensorPath + "/Out/Yellow",
                sensorPath + "/Out/Red"
            ])

            values.extend([
                False,
                False,
                False
            ])

        system.tag.writeBlocking(tagPaths, values)

        return True

    except Exception as e:

        LOGGER.error("clearOutputs() : {}".format(str(e)))
        return False


def getSensorByBin(binID):
    """
    Returns the sensor path mapped to the supplied Bin ID.
    """

    try:

        sensors = system.tag.browse(DEVICES).getResults()

        for sensor in sensors:

            sensorPath = str(sensor["fullPath"])

            value = system.tag.readBlocking([
                sensorPath + "/Bin"
            ])[0].value

            if int(value) == int(binID):
                return sensorPath

        return None

    except Exception as e:

        LOGGER.error("getSensorByBin() : {}".format(str(e)))
        return None


def activateCurrentStep():
    """
    Activates the current recipe step.

    Reads the current step from the RecipeDataset Memory Tag,
    updates the runtime tags, and activates the expected sensor.
    """

    try:

        LOGGER.info("========== activateCurrentStep() ==========")

        # --------------------------------------------------
        # Read Runtime
        # --------------------------------------------------

        runtime = system.tag.readBlocking([

            RUNTIME + "CurrentStep",
            RUNTIME + "RecipeDataset"

        ])

        stepNo = int(runtime[0].value)
        recipeDataset = runtime[1].value

        LOGGER.info("Current Step : {}".format(stepNo))

        # --------------------------------------------------
        # Validate Dataset
        # --------------------------------------------------

        if recipeDataset is None:
            raise Exception("RecipeDataset is empty.")

        totalRows = recipeDataset.getRowCount()

        LOGGER.info("Recipe Dataset Rows : {}".format(totalRows))

        row = stepNo - 1

        if row < 0 or row >= totalRows:

            message = "Recipe step {} not found.".format(stepNo)

            LOGGER.error(message)

            system.tag.writeBlocking(

                [

                    RUNTIME + "MachineState",
                    RUNTIME + "StatusMessage"

                ],

                [

                    "ERROR",
                    message

                ]

            )

            return False

        # --------------------------------------------------
        # Read Dataset Row
        # --------------------------------------------------

        expectedBin = int(recipeDataset.getValueAt(row, "bin_id"))
        quantity = int(recipeDataset.getValueAt(row, "quantity"))
        partNumber = str(recipeDataset.getValueAt(row, "part_number"))
        partName = str(recipeDataset.getValueAt(row, "part_name"))
        instruction = recipeDataset.getValueAt(row, "instruction") or ""

        LOGGER.info(

            "Row={} | Bin={} | Qty={} | Part={} | Name={}".format(

                row,
                expectedBin,
                quantity,
                partNumber,
                partName

            )

        )

        # --------------------------------------------------
        # Find Sensor
        # --------------------------------------------------

        sensorPath = getSensorByBin(expectedBin)

        if sensorPath is None:

            message = "No sensor mapped to Bin {}".format(expectedBin)

            LOGGER.error(message)

            system.tag.writeBlocking(

                [

                    RUNTIME + "MachineState",
                    RUNTIME + "StatusMessage"

                ],

                [

                    "ERROR",
                    message

                ]

            )

            return False

        LOGGER.info("Sensor Path : {}".format(sensorPath))

        # --------------------------------------------------
        # Clear Previous Outputs
        # --------------------------------------------------

        if not clearOutputs():
            raise Exception("Unable to clear sensor outputs.")
        # --------------------------------------------------
        # Write Runtime
        # --------------------------------------------------

        tagPaths = [

            sensorPath + "/Out/Green",

            RUNTIME + "ExpectedBinID",
            RUNTIME + "CurrentQuantity",
            RUNTIME + "CurrentPartNumber",
            RUNTIME + "CurrentPartName",

            RUNTIME + "MachineState",
            RUNTIME + "RecipeRunning",
            RUNTIME + "StatusMessage"

        ]

        values = [

            True,

            expectedBin,
            quantity,
            partNumber,
            partName,

            "RUNNING",
            True,
            instruction

        ]

        results = system.tag.writeBlocking(tagPaths, values)

        LOGGER.info("----- Write Results -----")

        for path, value, quality in zip(tagPaths, values, results):

            LOGGER.info(

                "{} | Value={} | Quality={}".format(

                    path,
                    value,
                    quality

                )

            )

        LOGGER.info("-------------------------")

        LOGGER.info(

            "Step {} Activated Successfully".format(stepNo)

        )

        return True

    except Exception as e:

        LOGGER.error(

            "activateCurrentStep() : {}".format(str(e))

        )

        system.tag.writeBlocking(

            [

                RUNTIME + "MachineState",
                RUNTIME + "StatusMessage"

            ],

            [

                "ERROR",
                str(e)

            ]

        )

        return False


def nextStep():
    """
    Advances recipe to the next step.
    """

    try:

        runtime = system.tag.readBlocking([

            RUNTIME + "CurrentStep",
            RUNTIME + "TotalSteps"

        ])

        currentStep = int(runtime[0].value)
        totalSteps = int(runtime[1].value)

        if currentStep < 1:
            raise Exception("Invalid Current Step")

        if totalSteps < 1:
            raise Exception("Invalid Total Steps")

        if currentStep < totalSteps:

            currentStep += 1

            system.tag.writeBlocking(

                [
                    RUNTIME + "CurrentStep"
                ],

                [
                    currentStep
                ]

            )

            LOGGER.info(
                "Moving to Step {}".format(currentStep)
            )

            return activateCurrentStep()

        LOGGER.info("Recipe Completed")

        clearOutputs()

        system.tag.writeBlocking(

            [

                RUNTIME + "RecipeRunning",
                RUNTIME + "MachineState",
                RUNTIME + "StatusMessage",
                RUNTIME + "ExpectedBinID"

            ],

            [

                False,
                "COMPLETED",
                "Recipe Completed",
                0

            ]

        )

        return True

    except Exception as e:

        LOGGER.error(
            "nextStep() : {}".format(str(e))
        )

        system.tag.writeBlocking(

            [

                RUNTIME + "MachineState",
                RUNTIME + "StatusMessage"

            ],

            [

                "ERROR",
                str(e)

            ]

        )

        return False