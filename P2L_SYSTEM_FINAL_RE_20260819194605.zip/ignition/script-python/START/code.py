LOGGER = system.util.getLogger("P2L.Sequence")

RUNTIME = "[P2L_TagProvider]Runtime/"


def startSequence():
    """
    Starts the loaded recipe by activating the first step.

    Returns:
        True  - Recipe started successfully
        False - Failed to start recipe
    """

    try:

        # --------------------------------------------------
        # Read Runtime Information
        # --------------------------------------------------

        runtime = system.tag.readBlocking([

            RUNTIME + "RecipeRunning",
            RUNTIME + "CurrentRecipeID",
            RUNTIME + "MachineState",
            RUNTIME + "RecipeDataset"

        ])

        recipeRunning = bool(runtime[0].value)
        recipeID = int(runtime[1].value)
        machineState = str(runtime[2].value)
        recipeDataset = runtime[3].value

        # --------------------------------------------------
        # Validations
        # --------------------------------------------------

        if recipeRunning:
            raise Exception(
                "Recipe is already running."
            )

        if recipeID <= 0:
            raise Exception(
                "No recipe has been loaded."
            )

        if machineState != "READY":
            raise Exception(
                "Machine must be in READY state. Current state: {}".format(
                    machineState
                )
            )

        if recipeDataset is None:
            raise Exception(
                "Recipe dataset is empty."
            )

        if recipeDataset.getRowCount() == 0:
            raise Exception(
                "Recipe contains no steps."
            )

        LOGGER.info(
            "Starting Recipe {}".format(
                recipeID
            )
        )

        # --------------------------------------------------
        # Activate First Step
        # --------------------------------------------------

        success = sequence.activateCurrentStep()

        if not success:

            raise Exception(
                "Failed to activate first recipe step."
            )

        LOGGER.info(
            "First recipe step activated."
        )

        # --------------------------------------------------
        # Start Production Cycle Timer
        # --------------------------------------------------

        try:

            cycleTimer.startCycle()

            LOGGER.info(
                "Production Cycle Timer Started."
            )

        except Exception as timerException:

            LOGGER.error(
                "Unable to start Production Cycle Timer."
            )

            LOGGER.error(
                str(timerException)
            )

            # ----------------------------------------------
            # Rollback Activated Outputs
            # ----------------------------------------------

            sequence.clearOutputs()

            # ----------------------------------------------
            # Restore Runtime State
            # ----------------------------------------------

            system.tag.writeBlocking(

                [

                    RUNTIME + "RecipeRunning",

                    RUNTIME + "MachineState",

                    RUNTIME + "StatusMessage"

                ],

                [

                    False,

                    "ERROR",

                    "Failed to start Production Cycle."

                ]

            )

            raise Exception(
                "Cycle Timer startup failed."
            )

        # --------------------------------------------------
        # Recipe Started Successfully
        # --------------------------------------------------

        LOGGER.info(
            "Recipe {} started successfully.".format(
                recipeID
            )
        )

        return True

    except Exception as e:

        LOGGER.error(
            "startSequence() : {}".format(
                str(e)
            )
        )

        system.tag.writeBlocking(

            [

                RUNTIME + "MachineState",

                RUNTIME + "StatusMessage"

            ],

            [

                "ERROR",

                str(e)

            ]

        )

        return False