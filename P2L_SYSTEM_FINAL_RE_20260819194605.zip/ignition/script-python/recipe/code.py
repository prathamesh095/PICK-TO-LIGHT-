# loadRecipe()

LOGGER = system.util.getLogger("P2L.Recipe")

RUNTIME = "[P2L_TagProvider]Runtime/"


def loadRecipe(productID):
    """
    Loads the active recipe into Gateway memory and initializes runtime.

    Returns:
        True  - Recipe loaded successfully
        False - Recipe not loaded
    """

    try:

      
        # Check if a Recipe is Already Loaded
       

        currentRecipeID = system.tag.readBlocking(

            [

                RUNTIME + "CurrentRecipeID"

            ]

        )[0].value

        if int(currentRecipeID) != 0:

            message = (
                "A recipe is already loaded. "
                "Please reset the system before loading another recipe."
            )

            LOGGER.warn(message)

            system.tag.writeBlocking(

                [

                    RUNTIME + "StatusMessage"

                ],

                [

                    message

                ]

            )

            return False

      
        # Get Active Recipe
       

        recipe = system.db.runNamedQuery(

            "Recipes/GetRecipeByProduct",

            {

                "productID": productID

            }

        )

        if len(recipe) == 0:

            system.tag.writeBlocking(

                [

                    RUNTIME + "MachineState",
                    RUNTIME + "StatusMessage"

                ],

                [

                    "ERROR",
                    "No active recipe found."

                ]

            )

            return False

        recipeID = int(recipe[0]["recipe_id"])

     
        # Load Entire Recipe Dataset
       

        recipeDataset = system.db.runNamedQuery(

            "Recipes/GetRecipeDataset",

            {

                "recipeID": recipeID

            }

        )

        if recipeDataset.getRowCount() == 0:

            system.tag.writeBlocking(

                [

                    RUNTIME + "MachineState",
                    RUNTIME + "StatusMessage"

                ],

                [

                    "ERROR",
                    "Recipe contains no steps."

                ]

            )

            return False

        totalSteps = recipeDataset.getRowCount()

        # Initialize Runtime
      

        system.tag.writeBlocking(

            [

                RUNTIME + "CurrentProductID",
                RUNTIME + "CurrentRecipeID",
                RUNTIME + "CurrentStep",
                RUNTIME + "TotalSteps",
                RUNTIME + "RecipeDataset",
                RUNTIME + "RecipeRunning",
                RUNTIME + "MachineState",
                RUNTIME + "StatusMessage"

            ],

            [

                productID,
                recipeID,
                1,
                totalSteps,
                recipeDataset,
                False,
                "READY",
                "Recipe Loaded Successfully."

            ]

        )

        LOGGER.info(

            "Recipe {} loaded successfully ({} Steps).".format(

                recipeID,
                totalSteps

            )

        )

        return True

    except Exception as e:

        LOGGER.error(

            "loadRecipe() : {}".format(str(e))

        )

        system.tag.writeBlocking(

            [

                RUNTIME + "MachineState",
                RUNTIME + "StatusMessage"

            ],

            [

                "ERROR",
                str(e)

            ]

        )

        return False