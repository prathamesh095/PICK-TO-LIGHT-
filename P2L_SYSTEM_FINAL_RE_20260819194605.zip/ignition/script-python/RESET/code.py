LOGGER = system.util.getLogger("P2L.Reset")

RUNTIME = "[P2L_TagProvider]Runtime/"



# Machine States


STATE_IDLE = "IDLE"
STATE_READY = "READY"
STATE_RUNNING = "RUNNING"
STATE_ERROR = "ERROR"
STATE_COMPLETED = "COMPLETED"



# Return Status


RESET_SUCCESS = "RESET_SUCCESS"
AUTHORIZATION_REQUIRED = "AUTHORIZATION_REQUIRED"
RESET_FAILED = "RESET_FAILED"



# Business Rules


MAX_OPERATOR_RESET_STEPS = 2



# Create Empty Recipe Dataset


def createEmptyRecipeDataset():

    headers = [

        "step_no",
        "bin_id",
        "instruction"

    ]

    return system.dataset.toDataSet(headers, [])



# Validate Reset Permission


# Validate Reset Permission
def validateResetPermission(currentStep, machineState):

    completedSteps = max(0, currentStep - 1)

    # --------------------------------------------------
    # Recipe Completed
    # Allow Reset Without Authorization
    # --------------------------------------------------
    if machineState == STATE_COMPLETED:

        return (

            True,

            "Recipe completed. Reset allowed."

        )

    # --------------------------------------------------
    # Mid-Cycle Protection
    # --------------------------------------------------
    if completedSteps > MAX_OPERATOR_RESET_STEPS:

        return (

            False,

            "Reset denied. More than {} steps have been completed. Supervisor/Admin approval required.".format(
                MAX_OPERATOR_RESET_STEPS
            )

        )

    # --------------------------------------------------
    # Reset Allowed
    # --------------------------------------------------
    return (

        True,

        "Reset Allowed"

    )


# Perform Reset


def performReset():

    # --------------------------------------------------
    # Clear All Active Outputs
    # --------------------------------------------------

    if not sequence.clearOutputs():

        raise Exception(
            "Unable to clear sensor outputs."
        )

    # --------------------------------------------------
    # Create Empty Recipe Dataset
    # --------------------------------------------------

    emptyDataset = createEmptyRecipeDataset()

    # --------------------------------------------------
    # Reset Runtime Tags
    # --------------------------------------------------

    system.tag.writeBlocking(

        [

            RUNTIME + "CurrentProductID",
            RUNTIME + "CurrentRecipeID",
            RUNTIME + "CurrentStep",
            RUNTIME + "TotalSteps",
            RUNTIME + "ExpectedBinID",
            RUNTIME + "RecipeRunning",
            RUNTIME + "MachineState",
            RUNTIME + "StatusMessage",
            RUNTIME + "RecipeDataset"

        ],

        [

            0,
            0,
            0,
            0,
            0,
            False,
            STATE_IDLE,
            "System reset completed. Ready to load a new recipe.",
            emptyDataset

        ]

    )

    LOGGER.info("Runtime reset completed successfully.")

    # --------------------------------------------------
    # Reset Cycle Timer
    # --------------------------------------------------

    cycleTimer.resetTimer()

    LOGGER.info("Cycle Timer reset completed successfully.")

    # --------------------------------------------------
    # Reset Completed
    # --------------------------------------------------

    return True



# Public Function


def resetSystem():

    """
    Returns

        RESET_SUCCESS
        AUTHORIZATION_REQUIRED
        RESET_FAILED
    """

    try:

        runtime = system.tag.readBlocking(

            [

                RUNTIME + "CurrentProductID",
                RUNTIME + "CurrentRecipeID",
                RUNTIME + "CurrentStep",
                RUNTIME + "RecipeRunning",
                RUNTIME + "MachineState"

            ]

        )

        currentProduct = runtime[0].value
        currentRecipe = runtime[1].value
        currentStep = int(runtime[2].value)
        recipeRunning = runtime[3].value
        machineState = str(runtime[4].value)

        LOGGER.info(

            "Reset Requested | Product={} | Recipe={} | Step={} | Running={} | State={}".format(

                currentProduct,
                currentRecipe,
                currentStep,
                recipeRunning,
                machineState

            )

        )

        allowed, message = validateResetPermission(

            currentStep,
            machineState

        )

        if not allowed:

            LOGGER.warn(message)

            system.tag.writeBlocking(

                [

                    RUNTIME + "StatusMessage"

                ],

                [

                    message

                ]

            )

            return AUTHORIZATION_REQUIRED

        performReset()

        return RESET_SUCCESS

    except Exception as e:

        LOGGER.error(

            "resetSystem() : {}".format(str(e))

        )

        system.tag.writeBlocking(

            [

                RUNTIME + "MachineState",
                RUNTIME + "StatusMessage"

            ],

            [

                STATE_ERROR,
                str(e)

            ]

        )

        return RESET_FAILED
        
        
        