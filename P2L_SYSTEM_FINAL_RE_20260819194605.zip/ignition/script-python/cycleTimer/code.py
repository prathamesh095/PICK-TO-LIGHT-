# ==========================================================

LOGGER = system.util.getLogger("CycleTimer")


# ==========================================================
# Runtime Tag Paths
# ==========================================================

RUNTIME = "[P2L_TagProvider]Runtime"

TIMER = RUNTIME + "/CycleTimer"


# ==========================================================
# Production Run Named Queries
# ==========================================================

CREATE_RUN_QUERY = \
"ProductionRuns/CreateRun"

UPDATE_RUN_NUMBER_QUERY = \
"ProductionRuns/UpdateRunNumber"

GET_RUN_NUMBER_QUERY = \
"ProductionRuns/GetRunNumber"

UPDATE_RUN_QUERY = \
"ProductionRuns/UpdateRunProgress"

COMPLETE_RUN_QUERY = \
"ProductionRuns/CompleteRun"

ABORT_RUN_QUERY = \
"ProductionRuns/AbortRun"

GET_PRODUCTION_STATISTICS_QUERY = \
"ProductionRuns/GetProductionStatistics"

PAUSE_RUN_QUERY = \
"ProductionRuns/PauseRun"

RESUME_RUN_QUERY = \
"ProductionRuns/ResumeRun"


# ==========================================================
# Timer Configuration
# ==========================================================

DATABASE_UPDATE_INTERVAL = 5

DEFAULT_OPERATOR = "SYSTEM"

DEFAULT_MACHINE = "P2L Station 01"


# ==========================================================
# Runtime Tag Helpers
# ==========================================================

def read(path):
    """
    Reads a single runtime tag.

    Example

        value = read(
            RUNTIME + "/MachineState"
        )

    Returns
        Tag Value
    """

    return system.tag.readBlocking(
        [path]
    )[0].value


# ----------------------------------------------------------

def write(tagDictionary):
    """
    Writes multiple runtime tags.

    Example

        write({

            TIMER + "/Running":True,

            TIMER + "/ElapsedSeconds":25

        })
    """

    paths = []

    values = []

    for path, value in tagDictionary.items():

        paths.append(path)

        values.append(value)

    system.tag.writeBlocking(
        paths,
        values
    )


# ----------------------------------------------------------

def exists(path):
    """
    Returns True if tag exists.
    """

    try:

        system.tag.readBlocking([path])

        return True

    except:

        return False


# ==========================================================
# Logging Helpers
# ==========================================================

def logHeader(title):
    """
    Prints a formatted section header.
    """

    LOGGER.info("")

    LOGGER.info(
        "========================================"
    )

    LOGGER.info(title)

    LOGGER.info(
        "========================================"
    )


# ----------------------------------------------------------

def logSeparator():

    LOGGER.info(
        "----------------------------------------"
    )


# ==========================================================
# Time Helper Functions
# ==========================================================

def secondsToTime(totalSeconds):
    """
    Converts seconds to HH:MM:SS
    """

    hours = totalSeconds // 3600

    minutes = (
        totalSeconds % 3600
    ) // 60

    remainingSeconds = (
        totalSeconds % 60
    )

    return "{:02d}:{:02d}:{:02d}".format(

        hours,

        minutes,

        remainingSeconds

    )


# ==========================================================
# Cycle State Helper Functions
# ==========================================================

def isRunning():
    """
    Returns True if the production
    cycle is currently running.
    """

    return read(

        TIMER + "/Running"

    )


# ----------------------------------------------------------

def isPaused():
    """
    Returns True if the production
    cycle is currently paused.
    """

    return read(

        TIMER + "/IsPaused"

    )


# ----------------------------------------------------------

def getPauseDuration():
    """
    Returns the current pause
    duration in seconds.
    """

    pauseStart = read(

        TIMER + "/PauseStartTime"

    )

    if pauseStart is None:

        return 0

    now = getCurrentTimestamp()

    elapsedMS = system.date.millisBetween(

        pauseStart,

        now

    )

    return int(

        elapsedMS / 1000

    )


# ----------------------------------------------------------

# ----------------------------------------------------------

def getNetElapsedSeconds():
    """
    Returns actual production time.
    Excludes all pause durations.
    """

    startTime = read(

        TIMER + "/StartTime"

    )

    if startTime is None:

        return 0

    totalPauseSeconds = read(

        TIMER + "/TotalPauseSeconds"

    )

    if totalPauseSeconds is None:

        totalPauseSeconds = 0

    # ------------------------------------------
    # Machine Currently Paused?
    # ------------------------------------------

    if isPaused():

        pauseDuration = getPauseDuration()

    else:

        pauseDuration = 0

    totalElapsed = getElapsedSeconds(

        startTime

    )

    return max(

        0,

        totalElapsed

        -

        totalPauseSeconds

        -

        pauseDuration

    )


# ----------------------------------------------------------

def getCurrentRunID():
    """
    Returns the active Run ID.
    """

    return read(

        TIMER + "/CurrentRunID"

    )


# ----------------------------------------------------------

def getCurrentRunNumber():
    """
    Returns the active Run Number.
    """

    return read(

        TIMER + "/CurrentRunNumber"

    )

# ----------------------------------------------------------

def getCurrentTimestamp():
    """
    Returns current timestamp.
    """

    return system.date.now()


# ----------------------------------------------------------

def getElapsedSeconds(startTime):
    """
    Calculates elapsed seconds from
    the supplied start time.
    """

    now = system.date.now()

    elapsedMS = system.date.millisBetween(

        startTime,

        now

    )

    return int(elapsedMS / 1000)
    
    
    
# ==========================================================
# Database Functions
# ==========================================================

def createRun(params):
    """
    Creates a new production run.

    Returns
    -------
    int
        Generated Run ID.
    """

    dataset = system.db.runNamedQuery(

        CREATE_RUN_QUERY,

        params

    )

    if dataset.getRowCount() == 0:

        raise Exception(

            "CreateRun returned no rows."

        )

    return dataset.getValueAt(

        0,

        "run_id"

    )


# ----------------------------------------------------------

def updateRunNumber(runID):
    """
    Generates a formatted run number.

    Example

        RUN-000001
    """

    system.db.runNamedQuery(

        UPDATE_RUN_NUMBER_QUERY,

        {

            "RunID": runID

        }

    )


# ----------------------------------------------------------

def getRunNumber(runID):
    """
    Returns the formatted Run Number.

    Example

        RUN-000001
    """

    dataset = system.db.runNamedQuery(

        GET_RUN_NUMBER_QUERY,

        {

            "RunID": runID

        }

    )

    if dataset.getRowCount() == 0:

        return ""

    return dataset.getValueAt(

        0,

        "run_number"

    )


# ----------------------------------------------------------

def updateRunProgress(
        runID,
        elapsedSeconds,
        completedSteps,
        machineState,
        status):
    """
    Updates the active production run.
    Called periodically while the
    recipe is running.
    """

    system.db.runNamedQuery(

        UPDATE_RUN_QUERY,

        {

            "RunID": runID,

            "ElapsedSeconds": elapsedSeconds,

            "CompletedSteps": completedSteps,

            "MachineState": machineState,

            "Status": status

        }

    )


# ----------------------------------------------------------

def completeRun(
        runID,
        actualCycleSeconds,
        completedSteps):
    """
    Completes a production run.
    """

    system.db.runNamedQuery(

        COMPLETE_RUN_QUERY,

        {

            "RunID": runID,

            "ActualCycleSeconds": actualCycleSeconds,

            "CompletedSteps": completedSteps

        }

    )


# ----------------------------------------------------------

def abortRun(
        runID,
        elapsedSeconds,
        completedSteps,
        reason):
    """
    Aborts the active production run.
    """

    system.db.runNamedQuery(

        ABORT_RUN_QUERY,

        {

            "RunID": runID,

            "ElapsedSeconds": elapsedSeconds,

            "CompletedSteps": completedSteps,

            "Reason": reason

        }

    )

# ----------------------------------------------------------
# Pause Production Run
# ----------------------------------------------------------

def pauseRun(runID):
    """
    Marks the production run
    as paused.
    """

    system.db.runNamedQuery(

        PAUSE_RUN_QUERY,

        {

            "RunID": runID

        }

    )

# ----------------------------------------------------------
# Resume Production Run
# ----------------------------------------------------------

def resumeRun(
        runID,
        totalPauseSeconds):
    """
    Marks the production run
    as resumed.
    """

    system.db.runNamedQuery(

        RESUME_RUN_QUERY,

        {

            "RunID": runID,

            "TotalPauseSeconds": totalPauseSeconds

        }

    )

# ----------------------------------------------------------
# Production Statistics
# ----------------------------------------------------------

def getProductionStatistics():
    """
    Returns production statistics used by the KPI Engine.
    """

    dataset = system.db.runNamedQuery(GET_PRODUCTION_STATISTICS_QUERY)

    if dataset.getRowCount() == 0:
        return {
            "TotalRuns": 0,
            "GoodRuns": 0,
            "FailedRuns": 0,
            "AverageCycle": 0,
            "BestCycle": 0
        }

    return {
        "TotalRuns": int(dataset.getValueAt(0, "total_runs")),
        "GoodRuns": int(dataset.getValueAt(0, "good_runs")),
        "FailedRuns": int(dataset.getValueAt(0, "failed_runs")),
        "AverageCycle": int(dataset.getValueAt(0, "average_cycle")),
        "BestCycle": int(dataset.getValueAt(0, "best_cycle"))
    }
    
    
# ==========================================================
# KPI Engine
# ==========================================================

def updateKPIs():
    """
    Updates all production KPI runtime tags.
    Called automatically whenever a
    production cycle completes.
    """

    try:

        logHeader("UPDATING KPI ENGINE")

        # --------------------------------------------------
        # Read Production Statistics
        # --------------------------------------------------

        stats = getProductionStatistics()

        totalRuns = stats["TotalRuns"]

        goodRuns = stats["GoodRuns"]

        failedRuns = stats["FailedRuns"]

        averageCycle = stats["AverageCycle"]

        bestCycle = stats["BestCycle"]

        # --------------------------------------------------
        # Calculate Production Efficiency
        # --------------------------------------------------

        if totalRuns > 0:

            efficiency = (

                float(goodRuns)

                / float(totalRuns)

            ) * 100.0

        else:

            efficiency = 0.0

        # --------------------------------------------------
        # Format Cycle Times
        # --------------------------------------------------

        averageCycleFormatted = secondsToTime(

            averageCycle

        )

        bestCycleFormatted = secondsToTime(

            bestCycle

        )

        # --------------------------------------------------
        # Update Runtime Tags
        # --------------------------------------------------

        write({

            TIMER + "/AverageCycleTime":

                averageCycle,

            TIMER + "/BestCycleTime":

                bestCycle,

            TIMER + "/AverageCycleTimeFormatted":

                averageCycleFormatted,

            TIMER + "/BestCycleTimeFormatted":

                bestCycleFormatted,

            TIMER + "/TotalRuns":

                totalRuns,

            TIMER + "/GoodRuns":

                goodRuns,

            TIMER + "/FailedRuns":

                failedRuns,

            TIMER + "/ProductionEfficiency":

                round(

                    efficiency,

                    2

                ),

            TIMER + "/LastDatabaseSync":

                getCurrentTimestamp()

        })

        # --------------------------------------------------
        # Logging
        # --------------------------------------------------

        LOGGER.info(

            "Total Runs : {}".format(

                totalRuns

            )

        )

        LOGGER.info(

            "Good Runs : {}".format(

                goodRuns

            )

        )

        LOGGER.info(

            "Failed Runs : {}".format(

                failedRuns

            )

        )

        LOGGER.info(

            "Average Cycle : {}".format(

                averageCycleFormatted

            )

        )

        LOGGER.info(

            "Best Cycle : {}".format(

                bestCycleFormatted

            )

        )

        LOGGER.info(

            "Efficiency : {:.2f}%".format(

                efficiency

            )

        )

    except Exception as e:

        LOGGER.error(

            "updateKPIs() FAILED"

        )

        LOGGER.error(

            str(e)

        )

        raise

# ----------------------------------------------------------

def productionRunExists(runID):
    """
    Checks whether a production
    run exists.
    """

    try:

        runNumber = getRunNumber(runID)

        return runNumber != ""

    except:

        return False
        
        
        
        
        
        
        
        
# ==========================================================
# Start Production Cycle
# ==========================================================

def startCycle():

    try:

        logHeader("START PRODUCTION CYCLE")

        # --------------------------------------------------
        # Prevent Duplicate Starts
        # --------------------------------------------------

        if read(TIMER + "/Running"):

            LOGGER.warn(

                "Production cycle already running."

            )

            return read(

                TIMER + "/CurrentRunID"

            )

        # --------------------------------------------------
        # Read Runtime Tags
        # --------------------------------------------------

        recipeID = read(

            RUNTIME + "/CurrentRecipeID"

        )

        productID = read(

            RUNTIME + "/CurrentProductID"

        )

        totalSteps = read(

            RUNTIME + "/TotalSteps"

        )

        currentPart = read(

            RUNTIME + "/CurrentPartNumber"

        )

        currentProduct = read(

            RUNTIME + "/CurrentPartName"

        )

        # --------------------------------------------------
        # Validate Runtime
        # --------------------------------------------------

        if recipeID <= 0:

            raise Exception(

                "Invalid Recipe ID."

            )

        if productID <= 0:

            raise Exception(

                "Invalid Product ID."

            )

        if totalSteps <= 0:

            raise Exception(

                "Recipe contains zero steps."

            )

        # --------------------------------------------------
        # Production Information
        # --------------------------------------------------

        operatorName = DEFAULT_OPERATOR

        machineName = DEFAULT_MACHINE

        # --------------------------------------------------
        # Create Database Record
        # --------------------------------------------------

        params = {

            "RecipeID": recipeID,

            "ProductID": productID,

            "OperatorName": operatorName,

            "MachineName": machineName,

            "TotalSteps": totalSteps

        }

        runID = createRun(

            params

        )

        updateRunNumber(

            runID

        )

        runNumber = getRunNumber(

            runID

        )

        LOGGER.info(

            "Run Created : {}".format(

                runNumber

            )

        )

        # --------------------------------------------------
        # Current Time
        # --------------------------------------------------

        startTime = getCurrentTimestamp()

        # --------------------------------------------------
        # Initialize Runtime Tags
        # --------------------------------------------------

        write({

            TIMER + "/CurrentRunID":

                runID,

            TIMER + "/CurrentRunNumber":

                runNumber,

            TIMER + "/Running":

                True,

            TIMER + "/StartTime":

                startTime,

            TIMER + "/CycleStartTimestamp":

                startTime,

            TIMER + "/EndTime":

                None,

            TIMER + "/ElapsedSeconds":

                0,

            TIMER + "/FormattedTime":

                "00:00:00",

            TIMER + "/PauseStartTime":

                None,

            TIMER + "/TotalPauseSeconds":

                0,

            TIMER + "/LastCycleTime":

                None

        })

        # --------------------------------------------------
        # Production Summary
        # --------------------------------------------------

        logSeparator()

        LOGGER.info(

            "Run Number : {}".format(

                runNumber

            )

        )

        LOGGER.info(

            "Recipe ID : {}".format(

                recipeID

            )

        )

        LOGGER.info(

            "Product ID : {}".format(

                productID

            )

        )

        LOGGER.info(

            "Part Number : {}".format(

                currentPart

            )

        )

        LOGGER.info(

            "Part Name : {}".format(

                currentProduct

            )

        )

        LOGGER.info(

            "Total Steps : {}".format(

                totalSteps

            )

        )

        LOGGER.info(

            "Machine : {}".format(

                machineName

            )

        )

        LOGGER.info(

            "Operator : {}".format(

                operatorName

            )

        )

        logSeparator()

        LOGGER.info(

            "Production Cycle Started Successfully."

        )

        return runID

    except Exception as e:

        LOGGER.error(

            "startCycle() FAILED"

        )

        LOGGER.error(

            str(e)

        )

        raise
        
        
        
        
# ==========================================================
# Live Timer Engine
# Gateway Timer Script
# Runs Every Second
# ==========================================================

def tick():

    try:

        # --------------------------------------------------
        # Is Production Active?
        # --------------------------------------------------

        if not isRunning():

            return

        # --------------------------------------------------
        # Read Runtime Information
        # --------------------------------------------------

        runID = getCurrentRunID()

        startTime = read(

            TIMER + "/StartTime"

        )

        if runID is None or runID <= 0:

            LOGGER.warn(

                "Invalid Run ID."

            )

            return

        if startTime is None:

            LOGGER.warn(

                "Start Time not initialized."

            )

            return

        # --------------------------------------------------
        # Calculate Net Production Time
        # --------------------------------------------------

        elapsedSeconds = getNetElapsedSeconds()

        formattedTime = secondsToTime(

            elapsedSeconds

        )

        # --------------------------------------------------
        # Read Runtime Status
        # --------------------------------------------------

        currentStep = read(

            RUNTIME + "/CurrentStep"

        )

        totalSteps = read(

            RUNTIME + "/TotalSteps"

        )

        machineState = read(

            RUNTIME + "/MachineState"

        )

        expectedBin = read(

            RUNTIME + "/ExpectedBinID"

        )

        statusMessage = read(

            RUNTIME + "/StatusMessage"

        )

        # --------------------------------------------------
        # Update Runtime Timer
        # --------------------------------------------------

        write({

            TIMER + "/ElapsedSeconds":

                elapsedSeconds,

            TIMER + "/FormattedTime":

                formattedTime

        })

        # --------------------------------------------------
        # Production Currently Paused?
        # --------------------------------------------------

        if isPaused():

            LOGGER.trace(

                "Run {} Paused ({})".format(

                    runID,

                    formattedTime

                )

            )

            return

        # --------------------------------------------------
        # Synchronize Database
        # --------------------------------------------------

        if elapsedSeconds > 0:

            if elapsedSeconds % DATABASE_UPDATE_INTERVAL == 0:

                updateRunProgress(

                    runID,

                    elapsedSeconds,

                    currentStep,

                    machineState,

                    "ACTIVE"

                )

                write({

                    TIMER + "/LastDatabaseSync":

                        getCurrentTimestamp()

                })

                LOGGER.trace(

                    "Run {} synchronized at {} sec".format(

                        runID,

                        elapsedSeconds

                    )

                )

        # --------------------------------------------------
        # Automatic Recipe Completion
        # --------------------------------------------------

        if machineState == "COMPLETED":

            LOGGER.info(

                "Machine State = COMPLETED"

            )

            stopCycle()

            return

        if currentStep >= totalSteps and totalSteps > 0:

            LOGGER.info(

                "Recipe Finished"

            )

            stopCycle()

            return

        # --------------------------------------------------
        # Debug Trace
        # --------------------------------------------------

        LOGGER.trace(

            "Run:{} | Step:{}/{} | Time:{} | Bin:{} | State:{} | Status:{}"

            .format(

                runID,

                currentStep,

                totalSteps,

                formattedTime,

                expectedBin,

                machineState,

                statusMessage

            )

        )

    except Exception as e:

        LOGGER.error(

            "tick() FAILED"

        )

        LOGGER.error(

            str(e)

        )

        raise
        
# ==========================================================
# Stop Production Cycle
# ==========================================================

# ==========================================================
# Stop Production Cycle
# ==========================================================

def stopCycle():

    try:

        logHeader("STOP PRODUCTION CYCLE")

        # --------------------------------------------------
        # Already Stopped?
        # --------------------------------------------------

        if not isRunning():

            LOGGER.warn(

                "Production cycle already stopped."

            )

            return

        # --------------------------------------------------
        # Read Runtime Information
        # --------------------------------------------------

        runID = getCurrentRunID()

        runNumber = getCurrentRunNumber()

        elapsedSeconds = read(

            TIMER + "/ElapsedSeconds"

        )

        formattedTime = read(

            TIMER + "/FormattedTime"

        )

        totalPauseSeconds = read(

            TIMER + "/TotalPauseSeconds"

        )

        completedSteps = read(

            RUNTIME + "/CurrentStep"

        )

        totalSteps = read(

            RUNTIME + "/TotalSteps"

        )

        machineState = read(

            RUNTIME + "/MachineState"

        )

        recipeID = read(

            RUNTIME + "/CurrentRecipeID"

        )

        productID = read(

            RUNTIME + "/CurrentProductID"

        )

        endTime = getCurrentTimestamp()

        # --------------------------------------------------
        # Complete Production Run
        # --------------------------------------------------

        completeRun(

            runID,

            elapsedSeconds,

            completedSteps

        )

        LOGGER.info(

            "Production Run Completed."

        )

        # --------------------------------------------------
        # Update Runtime Tags
        # --------------------------------------------------

        write({

            TIMER + "/Running":

                False,

            TIMER + "/IsPaused":

                False,

            TIMER + "/EndTime":

                endTime,

            TIMER + "/LastCycleTime":

                formattedTime,

            TIMER + "/PauseStartTime":

                None

        })

        # --------------------------------------------------
        # Update KPI Engine
        # --------------------------------------------------

        updateKPIs()

        # --------------------------------------------------
        # Production Summary
        # --------------------------------------------------

        logSeparator()

        LOGGER.info(

            "Run Number : {}".format(

                runNumber

            )

        )

        LOGGER.info(

            "Run ID : {}".format(

                runID

            )

        )

        LOGGER.info(

            "Recipe ID : {}".format(

                recipeID

            )

        )

        LOGGER.info(

            "Product ID : {}".format(

                productID

            )

        )

        LOGGER.info(

            "Completed Steps : {} / {}".format(

                completedSteps,

                totalSteps

            )

        )

        LOGGER.info(

            "Machine State : {}".format(

                machineState

            )

        )

        LOGGER.info(

            "Net Production Time : {}".format(

                formattedTime

            )

        )

        LOGGER.info(

            "Paused Time : {}".format(

                secondsToTime(

                    totalPauseSeconds

                )

            )

        )

        LOGGER.info(

            "Total Production Seconds : {}".format(

                elapsedSeconds

            )

        )

        logSeparator()

        LOGGER.info(

            "Production Cycle Finished Successfully."

        )

    except Exception as e:

        LOGGER.error(

            "stopCycle() FAILED"

        )

        LOGGER.error(

            str(e)

        )

        raise        

# ==========================================================
# Pause Production Cycle
# ==========================================================

def pauseCycle():

    try:

        logHeader("PAUSE PRODUCTION CYCLE")

        # --------------------------------------------------
        # Production Active?
        # --------------------------------------------------

        if not isRunning():

            LOGGER.warn(

                "No active production cycle."

            )

            return

        # --------------------------------------------------
        # Already Paused?
        # --------------------------------------------------

        if isPaused():

            LOGGER.warn(

                "Production cycle already paused."

            )

            return

        # --------------------------------------------------
        # Runtime Information
        # --------------------------------------------------

        runID = getCurrentRunID()

        pauseTime = getCurrentTimestamp()

        # --------------------------------------------------
        # Update Runtime
        # --------------------------------------------------

        write({

            TIMER + "/IsPaused":

                True,

            TIMER + "/PauseStartTime":

                pauseTime

        })

        # --------------------------------------------------
        # Update Database
        # --------------------------------------------------

        pauseRun(

            runID

        )

        # --------------------------------------------------
        # Logging
        # --------------------------------------------------

        LOGGER.info(

            "Run ID : {}".format(

                runID

            )

        )

        LOGGER.info(

            "Paused At : {}".format(

                pauseTime

            )

        )

        LOGGER.info(

            "Production Cycle Paused."

        )

    except Exception as e:

        LOGGER.error(

            "pauseCycle() FAILED"

        )

        LOGGER.error(

            str(e)

        )

        raise
        
        
        
        
# ==========================================================
# Resume Production Cycle
# ==========================================================

# ==========================================================
# Resume Production Cycle
# ==========================================================

def resumeCycle():

    try:

        logHeader("RESUME PRODUCTION CYCLE")

        # --------------------------------------------------
        # Is Production Running?
        # --------------------------------------------------

        if not isRunning():

            LOGGER.warn(

                "No active production cycle."

            )

            return

        # --------------------------------------------------
        # Is Cycle Paused?
        # --------------------------------------------------

        if not isPaused():

            LOGGER.warn(

                "Production cycle is not paused."

            )

            return

        # --------------------------------------------------
        # Runtime Information
        # --------------------------------------------------

        runID = getCurrentRunID()

        pauseDuration = getPauseDuration()

        totalPauseSeconds = read(

            TIMER + "/TotalPauseSeconds"

        )

        if totalPauseSeconds is None:

            totalPauseSeconds = 0

        totalPauseSeconds += pauseDuration

        resumeTime = getCurrentTimestamp()

        # --------------------------------------------------
        # Update Runtime Tags
        # --------------------------------------------------

        write({

            TIMER + "/IsPaused":

                False,

            TIMER + "/PauseStartTime":

                None,

            TIMER + "/TotalPauseSeconds":

                totalPauseSeconds

        })

        # --------------------------------------------------
        # Update Database
        # --------------------------------------------------

        resumeRun(

            runID,

            totalPauseSeconds

        )

        # --------------------------------------------------
        # Logging
        # --------------------------------------------------

        LOGGER.info(

            "Run ID : {}".format(

                runID

            )

        )

        LOGGER.info(

            "Resumed At : {}".format(

                resumeTime

            )

        )

        LOGGER.info(

            "Pause Duration : {}".format(

                secondsToTime(

                    pauseDuration

                )

            )

        )

        LOGGER.info(

            "Total Pause : {}".format(

                secondsToTime(

                    totalPauseSeconds

                )

            )

        )

        LOGGER.info(

            "Production Cycle Resumed Successfully."

        )

    except Exception as e:

        LOGGER.error(

            "resumeCycle() FAILED"

        )

        LOGGER.error(

            str(e)

        )

        raise
        
        
        
def resetTimer():

    write({

        TIMER + "/Running": False,

        TIMER + "/IsPaused": False,

        TIMER + "/CurrentRunID": 0,

        TIMER + "/CurrentRunNumber": "",

        TIMER + "/StartTime": None,

        TIMER + "/EndTime": None,

        TIMER + "/CycleStartTimestamp": None,

        TIMER + "/PauseStartTime": None,

        TIMER + "/ElapsedSeconds": 0,

        TIMER + "/FormattedTime": "00:00:00",

        TIMER + "/TotalPauseSeconds": 0,
        
        RUNTIME + "/WrongPickCount": 0

    })